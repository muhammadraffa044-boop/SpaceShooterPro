SPACE SHOOTER PRO - PROYEK ANDROID

Isi:
- Game HTML5 offline dengan kontrol sentuh
- Aplikasi Android pembungkus WebView (Java)
- Mode layar penuh dan orientasi portrait
- Skor terbaik tersimpan di perangkat
- Level, meteor, UFO, dan boss

CARA MEMBUAT APK:
1. Instal Android Studio di komputer.
2. Ekstrak ZIP ini.
3. Buka folder SpaceShooterPro di Android Studio.
4. Tunggu Gradle Sync selesai. Pastikan Android SDK Platform 35 terpasang.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk

Catatan:
- File ini adalah proyek/source Android Studio, bukan APK yang sudah dikompilasi.
- Build memerlukan Android Studio, Android SDK, dan koneksi internet pertama kali untuk mengunduh Gradle/Android plugin.
- Package: com.example.spaceshooter
- Minimum Android: 6.0 (API 23)
